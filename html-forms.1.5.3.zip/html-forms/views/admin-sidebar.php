<div>

	<div>
		<h3>Our Other Plugins</h3>
		<div style="margin: 12px 0;">
			<div><strong><a href="https://whitewp.com">White Label</a></strong></div>
			<div>White Label WordPress and make life easier for your clients.</div>
		</div>

		<div style="margin: 12px 0;">
			<div><strong><a href="https://termsplugin.com/">WP Terms Popup</a></strong></div>
			<div>Control access to your WordPress website with a popup.</div>
		</div>

		<div style="margin: 12px 0;">
			<div><strong><a href="https://chimpbridge.com/">ChimpBridge</a></strong></div>
			<div>Create and send Mailchimp campaigns in WordPress.</div>
		</div>

		<div style="margin: 12px 0;">
			<div><strong><a href="https://removewcfeatures.com/">Remove WooCommerce Features</a></strong></div>
			<div>Instantly change your WooCommerce store's layout and features.</div>
		</div>
	</div>

</div>


